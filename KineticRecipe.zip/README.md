# KineticRecipe

Forge 1.20.1 recipe editor using server-side memory recipe replacement.

- Minecraft: `1.20.1`
- Forge: `47.4.2`
- Java: `17`
- Required: `kineticcore`
- Unified recipe config: `config/kineticcore/recipes.json`
- Added and removed recipes are applied directly to the active server `RecipeManager`.
- No external recipe scripting runtime or generated recipe datapack is used.
